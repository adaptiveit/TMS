@extends('layouts.plane')
@section('page_heading') gg @endsection
@section('content')

<div class="col-lg-12">
    <div class="panel panel-default filterable">
        <div class="panel-heading">
            <div class="panel-title">test List</div>
            <div class="pull-right">
               
            </div>
        </div>
        <div class="panel-body">   
            <div class="table-responsive">
                <table id="data-table" class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr class="filters">
							<th><input type="text" class="form-control" placeholder="#" disabled></th>
                            <th><input type="text" class="form-control" placeholder="Fleettype" disabled></th>
                            <th><input type="text" class="form-control" placeholder="intercharge_id" disabled></th>
                            <th><input type="text" class="form-control" placeholder="status" disabled></th>
                            <th>Action</th>
                        </tr>
                    </thead>
                   
                    <tbody>
                        @foreach($fleets as $key => $fleet)
                      
                        <tr>
							 <td>{{ $fleet->fleet_type_id }}</td>
                            <td>{{ $fleet->fleet_type }}</td>
                            <td>{{ $fleet->incharge_id }}</td>
                            <td>{{ $fleet->status }}</td>
                            
                            <td>
                                <span class="btn-group" nowrap>
                               
                                    <button type="submit" class="xcrud-action btn btn-danger btn-sm" title="Remove"><i class="fa fa-trash-o"></i></button>
                                    {{ Form::close() }}
                                  
                                </span>
                            </td>
                            
                            
                           
                            
                            
                          
                            
                            
                            
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
@stop
